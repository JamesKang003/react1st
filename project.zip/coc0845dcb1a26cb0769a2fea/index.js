// Spend a minute memorizing the line below
// Re-write the line of code as best you can from memory
ReactDOM.render(<p>Hi, my name is Bob!</p>, document.querySelector())